package com.atguigu2.dao;

public interface OrderDAO {

}

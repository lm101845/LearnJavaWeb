package com.atguigu2.dao;

public class OrderDAOImpl extends BaseDAO implements OrderDAO {

}
